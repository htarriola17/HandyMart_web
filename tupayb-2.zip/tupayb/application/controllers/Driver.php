<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Driver extends CI_Controller {
    
	public function view()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar');
        $this->load->view('admin/driver/view');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
	}
}
