<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
    
	public function index()
	{
		$this->load->view('register/register');
	}

	public function insert(){
        $this->load->library('form_validation');

        //here are the validation entry
        $this->form_validation->set_rules('fname', 'Name', 'required');
        $this->form_validation->set_rules('lname', 'Last Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|is_unique[tbl_users.email]');
        $this->form_validation->set_rules('contact', 'Contact', 'required|is_unique[tbl_users.email]|numeric|greater_than[0]');
        $this->form_validation->set_rules('address', 'Contact', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('password1', 'Password Confirmation', 'required|matches[password]');

        if ($this->form_validation->run() == FALSE)
        {
                $this->register();
        }
        else
        {
                echo 'success';
            
                if($this->form_validation->run())
                {
                $data = array(
                'fname'  => $this->input->post('fname'),
                'lname'  => $this->input->post('lname'),
                'email'  => $this->input->post('email'),
                'contact'  => $this->input->post('contact'),
                'address'  => $this->input->post('address'),
                'password' => $this->input->post('password'));
                
                $this->load->model('Login_model');
                $id = $this->Login_model->insert($data);               
                redirect('Login');
            }
        }
       
    }
}
