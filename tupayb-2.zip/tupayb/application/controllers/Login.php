<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model('Login_model');
      }
     
      public function index(){
        $this->load->view('Login/login');
      }
     
      public function auth(){
        $email    = $this->input->post('email',TRUE);
        $password = $this->input->post('password',TRUE);
        $validate = $this->Login_model->validate($email,$password);
        
        if($validate->num_rows() > 0){
        $data  = $validate->row_array();
        $name  = $data['fname'];
        $email = $data['email'];
        $level = $data['user_level'];
        $sesdata = array(
            'fname'  => $name,
            'email'     => $email,
            'user_level'     => $level,
            'logged_in' => TRUE);
            
        $this->session->set_userdata($sesdata);
        // access login for admin
        if($level === '1'){

            redirect('User');
 
        // access login for staff
        }elseif($level === '2'){
            redirect('Admin');
 
        // access login for author
        }else{
            redirect('');
        }
        }else{
        echo $this->session->set_flashdata('msg','Username/ Password is Wrong Or Account does not exist');
        redirect('Login');
        }
    }
            function logout(){
                redirect('login');
            }

      public function register(){
        $this->load->view('register/register');
    }

    public function insert(){
        $this->load->library('form_validation');

        //here are the validation entry
        $this->form_validation->set_rules('fname', 'Name', 'required');
        $this->form_validation->set_rules('lname', 'Last Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|is_unique[tbl_users.email]');
        $this->form_validation->set_rules('contact', 'Contact', 'required|is_unique[tbl_users.email]|numeric|greater_than[0]');
        $this->form_validation->set_rules('address', 'Contact', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('password1', 'Password Confirmation', 'required|matches[password]');

        if ($this->form_validation->run() == FALSE)
        {
                $this->register();
        }
        else
        {
                echo 'success';
            
                if($this->form_validation->run())
                {
                $data = array(
                'fname'  => $this->input->post('fname'),
                'lname'  => $this->input->post('lname'),
                'email'  => $this->input->post('email'),
                'contact'  => $this->input->post('contact'),
                'address'  => $this->input->post('address'),
                'password' => $this->input->post('password'));
                
                $this->load->model('Login_model');
                $id = $this->Login_model->insert($data);               
                redirect('Login');
            }
        }
       
    }

     
    }