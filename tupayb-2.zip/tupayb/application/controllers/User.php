<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
    
    public function index()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar_user');
        $this->load->view('user/index');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }
    
    public function view()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar');
        $this->load->view('admin/user/view');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }

    public function product()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar_user');
        $this->load->view('user/product');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }

    public function washing()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar_user');
        $this->load->view('user/washing');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }

    public function table()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar_user');
        $this->load->view('user/table');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }

    public function chair()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar_user');
        $this->load->view('user/chair');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }

    public function profile(){
        $this->load->view('include/top');
        $this->load->view('include/sidebar_user');
        $this->load->view('user/profile');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }
    
}
