<?php
class hackathon extends CI_Controller {

    public function __construct() {

        parent::__construct();

        $this->load->database();

        $this->load->model('oirsmodel');

    }
    
    public function LoginUser(){
        
        $email = $this->input->post('email');
        
        $password = $this->input->post('password');
        
        $usercredentials = [ 'email' => $email,
                             'password' => sha1($password)];
                             
        $user = $this->oirsmodel->getItems('Users',$usercredentials);
        if($user == true){
    
        $response['error2'] = false; 
        $response['message2'] = "Congratulations Account Successfully created!";
        }else{
        $response['error2'] = true; 
        $response['message2'] = "Account Login Failed!";
        }
        echo json_encode($response);
        
    }

    public function RegisterUser(){

        $image = $this->input->post('image');

        file_put_contents('./uploads/'.time().'.jpg', base64_decode($image));    

        $email = $this->input->post('email',true);

        $firstname = $this->input->post('fname',true);

        $middlename = $this->input->post('mname',true);

        $lastname  = $this->input->post('lname',true);

        $contact  = $this->input->post('contact',true);

        $username  = $this->input->post('username',true);

        $address = $this->input->post('address',true);

        $password = $this->input->post('password',true);

        $userinfo = [ 'fname' =>$firstname,

                     'lname' => $lastname,

                      'mname' => $middlename,

                      'contactno' => $contact,

                      'username' => $username,

                      'address' => $address,

                      'password' => sha1($password),

                      'email' => $email,

                      'imgprofile' => time().'.jpg'
                    ];
        $this->oirsmodel->insertRecord('Users',$userinfo);
        $response['error2'] = false; 
        $response['message2'] = "Congratulations Account Successfully created!";
        echo json_encode($response);

    }
}
?>