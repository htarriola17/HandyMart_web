<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Store extends CI_Controller {

    public function index()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar_store');
        $this->load->view('store/index');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }
    
	public function view()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar');
        $this->load->view('admin/store/view');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }

        public function insert(){
            $this->load->library('form_validation');
    
            //here are the validation entry
            $this->form_validation->set_rules('product', 'Product', 'required');
            $this->form_validation->set_rules('description', 'Description', 'required');
            $this->form_validation->set_rules('quantity', 'Quantity', 'required|numeric');
            $this->form_validation->set_rules('price', 'Price', 'required|numeric|greater_than[0]');
    
            if ($this->form_validation->run() == FALSE)
            {
                    $this->store();
            }
            else
            {
                    echo 'success';
                
                    if($this->form_validation->run())
                    {
                    $data = array(
                    'product'  => $this->input->post('product'),
                    'description'  => $this->input->post('description'),
                    'quantity'  => $this->input->post('quantity'),
                    'price'  => $this->input->post('price'));
                    
                    $this->load->model('Product_model');
                    $id = $this->Product_model->insert($data);               
                    redirect('store');
                }
            }
           
        }
       
    
    
}
