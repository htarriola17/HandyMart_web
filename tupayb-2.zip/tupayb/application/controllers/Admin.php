<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    
    public function index()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar');
        $this->load->view('admin/index');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }    

    public function store()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar');
        $this->load->view('admin/store/index');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }
    

    public function user()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar');
        $this->load->view('admin/user/index');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }

    public function driver()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar');
        $this->load->view('admin/driver/driver');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }
    
    public function inbox()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar');
        $this->load->view('admin/inbox');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }

    public function archive()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar');
        $this->load->view('admin/archive');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
    }
    
    public function profile()
	{
        $this->load->view('include/top');
        $this->load->view('include/sidebar');
        $this->load->view('admin/profile');
        $this->load->view('include/footer');
        $this->load->view('include/bottom');
	}
}
