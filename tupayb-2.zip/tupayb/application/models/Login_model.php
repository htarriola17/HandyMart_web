<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model{
 
  public function validate($email,$password){
    $this->db->where('email',$email);
    $this->db->where('password',$password);
    $result = $this->db->get('tbl_users', 2);
    return $result;
  }

 
  public function insert($data){
    $this->db->insert('tbl_users',$data);
    }
}