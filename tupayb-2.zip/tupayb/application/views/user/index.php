

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <div class="box">



        <!--start container-->
        <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
          <h2 style="text-align: center;"> WELCOME TO TUPAYB!!</h2><br>
            <form class="navbar-form navbar-right" role="search">
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Search">
              </div>
              <button type="submit" class="btn btn-default">Submit</button>
            </form>
        </div>
      

        <!-- Section -->
        <div class="section">


        <div class="panel panel-default col-md-4" style="max-width: 20rem; margin-left: 5%;">
        <div class="card-header"></div>
            <div class="card" style="width: 18rem;">
              <img class="card-img-top img-responsive" src="<?=base_url()?>assets/images/thumb_img/oven.jpg" alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Microwave</h4>
                <p class="card-text">This microwave is just the best man. It cooks everything!</p>
                <a href="<?=base_url('User/product')?>" class="btn btn-primary">View</a>
              </div>
            </div>
        </div>

        <div class="panel panel-default col-md-4" style="max-width: 20rem; margin-left: 5%;">
        <div class="card-header"></div>
            <div class="card" style="width: 18rem;">
              <img class="card-img-top img-responsive" src="<?=base_url()?>assets/images/thumb_img/wm.jpg" alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Washing Machine</h4>
                <p class="card-text">This washing machine is so good you'll wan't to wash yourself in it</p>
                <a href="<?=base_url('User/washing')?>" class="btn btn-primary">View</a>
              </div>
            </div>
        </div>

        <div class="panel panel-default col-md-4" style="max-width: 20rem; margin-left: 5%;">
        <div class="card-header"></div>
            <div class="card" style="width: 18rem;">
              <img class="card-img-top img-responsive" src="<?=base_url()?>assets/images/thumb_img/lamesa.jpg" alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Table</h4>
                <p class="card-text">This table can carry anything. Even you lazy bum.</p>
                <a href="<?=base_url('User/table')?>" class="btn btn-primary">View</a>
              </div>
            </div>
        </div>

        <div class="panel panel-default col-md-4" style="max-width: 20rem; margin-left: 5%;">
        <div class="card-header"></div>
            <div class="card" style="width: 18rem;">
              <img class="card-img-top img-responsive" src="<?=base_url()?>assets/images/thumb_img/upuan.jpg" alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Chair</h4>
                <p class="card-text">This chair can support your weight. Even your problematic life.</p>
                <a href="<?=base_url('User/chair')?>" class="btn btn-primary">View</a>
              </div>
            </div>
        </div>

        <!-- Section End -->
        </div>


        </div>
        </div>
        <!--end container-->
      </div>
      <!-- /.box -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->







                















