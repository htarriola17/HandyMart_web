<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Register</title>
        <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
      
<?php if(validation_errors()): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <?php echo validation_errors(); ?>
</div>
<?php endif; ?>
  
        <div class="container col-md-4 col-md-offset-4" style="margin-top: 1%;">
            <form class="form-signin" action="<?=base_url()?>Login/insert" method="post">
      
            <h2 class="form-horizontal" style="text-align: center;" >Register</h2>
            <?php echo $this->session->flashdata('msg');?>
            <label>First Name</label>
            <input id="fname" class="form-control" placeholder="First Name" name="fname" required autofocus><br>
            <label>Last Name</label>
            <input id="lname" class="form-control" placeholder="Last Name" name="lname" required autofocus><br>
            <label>Email</label>
            <input id="email" type="email" class="form-control" placeholder="Email" name="email" required><br>
            <label>Contact</label>
            <input id="contact" class="form-control" placeholder="Contact" name="contact" required autofocus><br>
            <label>Address</label>
            <input id="address" class="form-control" placeholder="Address" name="address" required><br>
            <label>Password</label>
            <input id="password" type="password" class="form-control" placeholder="Password" name="password" required autofocus><br>
            <label>Confirm Password</label>
            <input id="password1" type="password" class="form-control" placeholder="Password" name="password1" required><br>

            <!-- Button (Double) -->
            <div class="form-group">
                <button id="" name="" class="btn btn-success">Register</button>
                <a id="" href="<?=base_url()?>Login" name="" class="btn btn-danger">Cancel</a>
            </div>
            </form>
        </div>
 
    <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
    </body>
</html>


  <!-- Default panel contents -->
  