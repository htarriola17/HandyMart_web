<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Sign In</title>
        <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
      
  
        <div class="container col-md-4 col-md-offset-4" style="margin-top: 10%;">
            <form class="form-signin" action="<?=base_url()?>login/auth" method="post">
            <div class="form-group">
            <h2 class="form-signin-heading" style="text-align: center;" >Sign In</h2>
                <label for="exampleInputEmail1">Email address</label>
                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
            </div>
 
            <!-- Button (Double) -->
            <div class="form-group">
                <button id="" name="" class="btn btn-success">Sign In</button>
                <a id="" href="<?=base_url()?>Register" name="" class="btn btn-danger">Register</a>
            </div>
            </form>
        </div>
 
    <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
    </body>
</html>


  <!-- Default panel contents -->
  