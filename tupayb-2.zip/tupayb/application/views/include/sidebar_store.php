<!-- Site wrapper -->
<div class="wrapper">


  <header class="main-header">
    <!-- Logo -->
    <a href="" class="logo">
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>TeamAng</b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    
    <nav class="navbar">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
    </nav>
    

    
  </header>

  

  <!-- =============================================== -->

  <!-- Left side column. contains the sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <br>
      <ul class="sidebar-menu" data-widget="tree">
      <li><a href="<?=base_url('Store/profile')?>"><span>Profile</span></a></li>
        <li><a href="<?=base_url('Store')?>"><span>Store</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>