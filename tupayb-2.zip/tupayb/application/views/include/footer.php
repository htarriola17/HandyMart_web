<footer class="main-footer">
    <strong>Copyright &copy; TeamAng</strong> All rights
    reserved.
  </footer>

</div>
<!-- ./wrapper -->