

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <div class="box">



        <!--start container-->
        <div class="container-fluid">
        <div class="row">
            <div class="panel">
                <div class="panel-heading"><h3><strong>User Profile</strong></h3></div>
                    
                <!-- Profile Image -->
                <div class="card card-primary card-outline">
                <div class="card-body box-profile">
                    <div class="text-center"><br>
                    <img class="profile-user-img img-fluid img-circle"
                        src="<?=base_url()?>assets/images/thumb_img/avatar.PNG" style="width: 200px" alt="User profile picture">
                    </div>

                    <h2 class="profile-username text-center" href="<?=base_url('user/profile')?>">USERNAME</h2>
                </div>
                <!-- /.card-body -->
                </div>
                <!-- /.card -->


                <!-- About Me Box -->
                <div class="card col-md-4 col-md-offset-1">
                <!-- /.card-header -->
                <div class="card-body">
                    <h3><strong><span class="fa fa-user"></span> First Name</strong></h3>
                    <p class="text-muted col-md-offset-1"  href="<?=base_url('user/profile')?>">First Name</p>

                    <h3><strong><span class="fa fa-user"></span> Email Address</strong></h3>
                    <p class="text-muted col-md-offset-1"  href="<?=base_url('user/profile')?>">Email</p>

                    <h3><strong><span class="fa fa-user"></span> Address</strong></h3>
                    <p class="text-muted col-md-offset-1"  href="<?=base_url('user/profile')?>">Address</p>
                </div>
                <!-- /.card-body -->
                </div>
                <!-- /.card -->

                <!-- About Me Box -->
                <div class="card col-md-4 col-md-offset-1">
                <!-- /.card-header -->
                <div class="card-body">
                    <h3><strong><span class="fa fa-user"></span> Last Name</strong></h3>
                    <p class="text-muted col-md-offset-1"  href="<?=base_url('user/profile')?>">Last Name</p>

                    <h3><strong><span class="fa fa-user"></span> Contact Number</strong></h3>
                    <p class="text-muted col-md-offset-1"  href="<?=base_url('user/profile')?>">Contact </p>

                    <h3><strong><span class="fa fa-user"></span> ID</strong></h3>
                    <p class="text-muted col-md-offset-1"  href="<?=base_url('user/profile')?>">ID </p>
                </div>
                <!-- /.card-body -->
                </div>
                <!-- /.card -->
                    
            
            </div>
        </div>
        </div>
        <!--end container-->
      </div>
      <!-- /.box -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

      
       
