

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <div class="box">

            <!--start container-->
        <div class="container-fluid">
        <div class="row">
            <div class="panel">
            <div class="panel-heading"><h3><strong>Driver Details</strong></h3></div>
            <form class="form-signin col-md-10 col-md-offset-1" action="" method="post">
            <label for="">ID</label>
            <input type="" readonly class="form-control" placeholder="ID" name="" required autofocus><br>
            <label for="">License Number</label>
            <input type="" readonly class="form-control" placeholder="License Number" name="" required><br>
            <label for="">First Name</label>
            <input type="" readonly class="form-control" placeholder="First Name" name="" required autofocus><br>
            <label for="">Last Name</label>
            <input type="" readonly class="form-control" placeholder="Last Name" name="" required><br>
            <label for="">Email</label>
            <input type="" readonly class="form-control" placeholder="Email" name="" required autofocus><br>
            <label for="">Contact</label>
            <input type="" readonly class="form-control" placeholder="Contact" name="" required><br>
            <label for="">Address</label>
            <input type="" readonly class="form-control" placeholder="Address" name="" required autofocus><br>
            <label for="" >Plate Number</label>
            <input type="" readonly class="form-control" placeholder="Plate Number" name="" required><br>

            <!-- Button (Double) -->
            <div class="form-group">
                <a id="" href="<?=base_url()?>Admin/driver" name="" class="btn btn-danger">Go Back</a>
            </div>
            </form>
        </div>



                            
                
                
            
            </div>
        </div>
        </div>
        <!--end container-->
      </div>
      <!-- /.box -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->







                