

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <div class="box">



        <!--start container-->
        <div class="container-fluid">
        <div class="row">
            <div class="panel">
            <div class="panel-heading"><h3><strong>Driver</strong></h3></div>

            <table class="table table-bordered table-dark">
                    <tr>
                    <th>ID</th><th>License Number</th><th>First Name</th><th>Last Name</th><th>Email</th><th>Contact</th><th>Address</th><th>Plate Number</th><th>Action</th>
                    </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>

                            <td>
                            
                                <a href="<?=base_url()?>Driver/view" type="button" class="btn btn-primary btn-md">
                                    <span class="fa fa-eye" aria-hidden="true">
                                    </span> 
                                </a>
                                <a href="<?=base_url()?>" type="button" class="btn btn-danger btn-md">
                                    <span class="fa fa-trash" aria-hidden="true">
                                    </span>
                                </a>
                                
                            
                            </td>
                        </tr>
                </table>
                <br>
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#myModaladd" style="margin-left: 1%; margin-top; 1%;">Add Driver</button>

                <!-- Modal Add -->
                <div class="modal fade" id="myModaladd" tabindex="-1" role="form">
                    <div class="modal-dialog modal-dialog-centered">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Add New Driver</h4>
                        </div>
                        <div class="modal-body">

                            <form class="form-signin" action="" method="post">
                            <label for="username">License Number</label>
                            <input type="email" class="form-control" placeholder="Email" name="email" required autofocus><br>
                            <label for="password">First Name</label>
                            <input type="password" class="form-control" placeholder="Password" name="password" required><br>
                            <label for="username">Last Name</label>
                            <input type="email" class="form-control" placeholder="Email" name="email" required autofocus><br>
                            <label for="password">Email</label>
                            <input type="password" class="form-control" placeholder="Password" name="password" required><br>
                            <label for="username">Contact</label>
                            <input type="email" class="form-control" placeholder="Email" name="email" required autofocus><br>
                            <label for="password">Address</label>
                            <input type="password" class="form-control" placeholder="Password" name="password" required><br>
                            <label for="password">Plate Number</label>
                            <input type="password" class="form-control" placeholder="Password" name="password" required><br>
                           
                            <div class="modal-footer">
                                <button type="button" class="btn btn-success" data-dismiss="modal">Add</button>
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                            </div>
                            </form> 
                    </div>
                    
                    </div>
                </div>
 
            
            </div>
        </div>
        </div>
        <!--end container-->
      </div>
      <!-- /.box -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->







                