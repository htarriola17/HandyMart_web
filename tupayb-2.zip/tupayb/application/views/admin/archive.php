

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <div class="box">



        <!--start container-->
        <div class="container-fluid">
        <div class="row">
            <div class="panel">
            <!-- Button (Double) -->
            <div class="form-group" >
            <div class="" style="margin-left: 1%; margin-top: 1%;">
                <button id="" name="" href="<?=base_url()?>admin/inbox" class="btn btn-success">Inbox</button>
                <a id="" href="<?=base_url()?>Admin/archive" name="" class="btn btn-primary">Archives</a>
            </div>
            </div>

            <table class="table table-bordered table-dark">
                    <tr>
                    <th>ID</th><th>Name</th><th>User Type</th><th>Subject</th><th>Action</th>
                    </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>

                            <td>
                            
                                <a href="<?=base_url()?>" type="button" class="btn btn-primary btn-md">
                                    <span class="fa fa-eye" aria-hidden="true">
                                    </span> 
                                </a>
                                <a href="<?=base_url()?>" type="button" class="btn btn-warning btn-md">
                                    <span class="fa fa-archive" aria-hidden="true">
                                    </span> 
                                </a>
                                <a href="<?=base_url()?>" type="button" class="btn btn-danger btn-md">
                                    <span class="fa fa-trash" aria-hidden="true">
                                    </span>
                                </a>
                                
                            
                            </td>
                        </tr>
                </table>
                
            
            </div>
        </div>
        </div>
        <!--end container-->
      </div>
      <!-- /.box -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->







                